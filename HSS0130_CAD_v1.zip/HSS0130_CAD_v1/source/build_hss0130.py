#!/usr/bin/env python3
"""HSS-0130 外形验证草模 v1，单位 mm。

此脚本根据照片估算建立可修改的近似模型，未恢复原厂工程尺寸。
W/D 使用世嘉公布的产品外包络；其余来源见 parameters.json 与 README_中文.md。
需 Python 3.10+、cadquery 2.8、numpy、trimesh。STEP 不保存本脚本的参数历史。

用法：
  python build_hss0130.py --out ../ --small-width 200
  python build_hss0130.py --out ../custom --params parameters.json --small-width 160
"""
from __future__ import annotations
import argparse
import json
import math
import sys
from dataclasses import dataclass, asdict, fields
from pathlib import Path
from typing import Any

import cadquery as cq
import numpy as np
import trimesh

@dataclass
class Parameters:
    # 只有前两项来自官方产品尺寸；没有证实底板和机柜版也精确等于此尺寸。
    width: float = 738.0
    depth: float = 230.0
    # 下列三项沿用上一轮照片估算，均需要实测确认。
    height: float = 70.0
    front_bulge: float = 20.0
    front_corner_radius: float = 30.0
    # 以下均为此次草模设计值，不是原件测量值。
    rear_corner_radius: float = 12.0
    top_edge_radius: float = 6.0
    bottom_edge_radius: float = 1.5
    wall: float = 5.0
    deck_thickness: float = 10.0
    bottom_recess_inset: float = 3.0
    bottom_thickness: float = 4.5
    clearance_per_side: float = 0.8
    panel_width: float = 650.0
    panel_depth: float = 150.0
    panel_rear_y: float = 65.0
    panel_front_bulge: float = 15.0
    panel_front_radius: float = 22.0
    panel_rear_radius: float = 6.0
    panel_recess_depth: float = 5.0
    panel_support_land: float = 8.0
    panel_thickness: float = 4.5
    instruction_width: float = 550.0
    instruction_depth: float = 42.0
    instruction_x: float = 50.0
    instruction_y: float = 29.0
    instruction_recess_depth: float = 1.0
    label_width: float = 100.0
    label_depth: float = 35.0
    label_x: float = -284.0
    label_y: float = 33.0
    label_recess_depth: float = 1.0
    bottom_hole_diameter: float = 4.2
    visual_panel_recess_depth: float = 1.0
    mesh_tolerance: float = 0.12
    mesh_angular_tolerance: float = 0.12

# 沿用第一版照片估算；孔中心各约 ±8 mm，不是制造公差。
# 坐标：X=左右中线，Y=后侧至玩家方向，Z=向上。
BOTTOM_HOLES = [(-340, 15), (-100, 15), (100, 15), (340, 15),
                (-345, 185), (-105, 210), (105, 210), (345, 185)]


def validate_params(p: Parameters) -> None:
    for field in fields(p):
        value = getattr(p, field.name)
        if not math.isfinite(value):
            raise ValueError(f'{field.name} 必须为有限数值。')
    if p.width <= 0 or p.depth <= 0 or p.height <= 0:
        raise ValueError('宽、深、高必须为正数。')
    if not (p.top_edge_radius < p.height / 2 and p.bottom_edge_radius < p.height / 2):
        raise ValueError('上下边圆角相对于高度过大。')
    if not (0 < p.bottom_recess_inset < p.wall < p.depth / 8):
        raise ValueError('需满足 0 < 底板凹位退距 < 壁厚 < 深度/8。')
    if p.deck_thickness <= p.panel_recess_depth or p.deck_thickness >= p.height:
        raise ValueError('顶框厚度必须大于面板凹槽深度、小于壳高。')
    if p.panel_thickness > p.panel_recess_depth:
        raise ValueError('占位面板厚度不可大于凹槽深度。')
    if p.bottom_recess_inset + p.clearance_per_side >= p.wall:
        raise ValueError('底板应保留搭接量；请减小间隙或增大壁厚。')
    if p.panel_width >= p.width - 2*p.wall or p.panel_depth+p.panel_rear_y >= p.depth:
        raise ValueError('占位面板超出外壳可用范围。')


def footprint(w: float, d: float, bulge: float, rf: float, rb: float) -> cq.Wire:
    """有直后边、前部浅圆弧和相切前角的闭合平面线框。

    bulge 为浅圆弧在 x=±(w/2-rf) 处相对中部的退距。
    前圆角与浅圆弧作解析相切，避免折线逼近和接缝尖角。
    """
    if not (w > 4*rf > 0 and 0 < rb < d/3 and 0 < bulge < d/3):
        raise ValueError('轮廓参数不合理。')
    a = w/2-rf
    big_r = (a*a + bulge*bulge)/(2*bulge)
    big_cy = d-big_r
    dist = big_r-rf
    if dist <= a:
        raise ValueError('前圆角与前弧无法构造内切关系。')
    side_cy = big_cy + math.sqrt(dist*dist-a*a)
    if side_cy <= rb:
        raise ValueError('侧边长度不足。')
    px = big_r*a/dist
    py = big_cy + big_r*(side_cy-big_cy)/dist
    theta = math.atan2(py-side_cy, px-a)
    right_mid = (a+rf*math.cos(theta/2), side_cy+rf*math.sin(theta/2))
    left_mid = (-right_mid[0], right_mid[1])
    q = math.sqrt(0.5)
    result = (cq.Workplane('XY')
        .moveTo(-w/2+rb, 0).lineTo(w/2-rb, 0)
        .threePointArc((w/2-rb+rb*q, rb-rb*q), (w/2, rb))
        .lineTo(w/2, side_cy)
        .threePointArc(right_mid, (px, py))
        .threePointArc((0, d), (-px, py))
        .threePointArc(left_mid, (-w/2, side_cy))
        .lineTo(-w/2, rb)
        .threePointArc((-w/2+rb-rb*q, rb-rb*q), (-w/2+rb, 0))
        .close().val())
    if not isinstance(result, cq.Wire) or not result.isValid():
        raise RuntimeError('生成轮廓失败。')
    return result


def offset(wire: cq.Wire, amount: float) -> cq.Wire:
    result = wire.offset2D(amount, 'arc')
    if len(result) != 1 or not result[0].isValid():
        raise RuntimeError(f'轮廓偏移失败，距离={amount}。')
    return result[0]


def prism(wire: cq.Wire, z: float, height: float) -> cq.Solid:
    w = wire.translate((0, 0, z))
    return cq.Solid.extrudeLinear(w, [], cq.Vector(0, 0, height))


def rounded_rect(width: float, depth: float, radius: float,
                 x: float, y: float, z: float, height: float) -> cq.Shape:
    return (cq.Workplane('XY').center(x,y).rect(width,depth).extrude(height)
            .edges('|Z').fillet(radius).val().translate((0,0,z)))


def build(p: Parameters) -> tuple[dict[str, cq.Shape], dict[str, cq.Wire]]:
    validate_params(p)
    ow = footprint(p.width, p.depth, p.front_bulge,
                   p.front_corner_radius, p.rear_corner_radius)
    base = prism(ow, 0, p.height)
    top_edges = [e for e in base.Edges()
                 if abs(e.BoundingBox().zmin-p.height)<1e-5
                 and abs(e.BoundingBox().zmax-p.height)<1e-5]
    base = base.fillet(p.top_edge_radius, top_edges)
    bottom_edges = [e for e in base.Edges()
                    if abs(e.BoundingBox().zmin)<1e-5 and abs(e.BoundingBox().zmax)<1e-5]
    base = base.fillet(p.bottom_edge_radius, bottom_edges)

    pw = footprint(p.panel_width, p.panel_depth, p.panel_front_bulge,
                   p.panel_front_radius, p.panel_rear_radius).translate((0,p.panel_rear_y,0))
    opening = offset(pw, -p.panel_support_land)
    inside = offset(ow, -p.wall)
    bottom_opening = offset(ow, -p.bottom_recess_inset)
    bw = offset(ow, -(p.bottom_recess_inset+p.clearance_per_side))
    panel_blank_wire = offset(pw, -p.clearance_per_side)

    # 从底部加工两级腔体：底板嵌位和内腔。留出顶框、面板承托边。
    shell = base.cut(prism(bottom_opening, -1, p.bottom_thickness+1))
    shell = shell.cut(prism(inside, p.bottom_thickness-0.05,
                           p.height-p.deck_thickness-p.bottom_thickness+0.05))
    shell = shell.cut(prism(pw, p.height-p.panel_recess_depth, p.panel_recess_depth+1))
    shell = shell.cut(prism(opening, -1, p.height+2))

    recesses = [rounded_rect(p.instruction_width, p.instruction_depth, 3,
                            p.instruction_x, p.instruction_y,
                            p.height-p.instruction_recess_depth, p.instruction_recess_depth+1),
                rounded_rect(p.label_width, p.label_depth, 3,
                            p.label_x, p.label_y,
                            p.height-p.label_recess_depth, p.label_recess_depth+1)]
    visual = base.cut(prism(pw, p.height-p.visual_panel_recess_depth,
                           p.visual_panel_recess_depth+1))
    for cutter in recesses:
        shell = shell.cut(cutter)
        visual = visual.cut(cutter)
    shell, visual = shell.clean(), visual.clean()

    bottom = prism(bw, 0, p.bottom_thickness)
    for x,y in BOTTOM_HOLES:
        hole = cq.Solid.makeCylinder(p.bottom_hole_diameter/2, p.bottom_thickness+2,
                                    cq.Vector(x,y,-1))
        bottom = bottom.cut(hole)
    bottom = bottom.clean()
    panel = prism(panel_blank_wire, p.height-p.panel_recess_depth, p.panel_thickness)
    parts = {'shell': shell, 'bottom': bottom, 'panel_blank': panel, 'visual_solid': visual}
    for name, shape in parts.items():
        if not shape.isValid() or len(shape.Solids()) != 1 or shape.Volume() <= 0:
            raise RuntimeError(f'{name} 未通过实体检查。')
    return parts, {'outer':ow, 'panel_recess_ASSUMED':pw,
                   'panel_opening_ASSUMED':opening, 'bottom_ASSUMED':bw}


def bed_orient(shape: cq.Shape, name: str, p: Parameters) -> cq.Shape:
    """仅打印文件翻转外壳，使大面积顶框朝下。CAD 装配姿态保持不变。"""
    if name == 'shell':
        shape = shape.rotate((0,0,0),(1,0,0),180)
    bb = shape.BoundingBox()
    return shape.translate((0, -bb.ymin, -bb.zmin))


def export_stl(shape: cq.Shape, path: Path, p: Parameters) -> trimesh.Trimesh:
    shape.exportStl(str(path), tolerance=p.mesh_tolerance,
                    angularTolerance=p.mesh_angular_tolerance, relative=False)
    mesh = trimesh.load_mesh(path, process=True)
    if not isinstance(mesh, trimesh.Trimesh):
        raise RuntimeError(f'{path.name} 不是单一网格对象。')
    mesh.merge_vertices()
    mesh.remove_unreferenced_vertices()
    if not mesh.is_watertight or not mesh.is_winding_consistent or mesh.volume <= 0:
        raise RuntimeError(f'{path.name} 未通过 STL 闭合/法向检查。')
    mesh.export(path)
    return mesh


def stats(shape: cq.Shape, mesh: trimesh.Trimesh | None = None) -> dict[str, Any]:
    bb = shape.BoundingBox()
    result:dict[str,Any] = {'valid_brep':shape.isValid(), 'solid_count':len(shape.Solids()),
                          'dimensions_mm':[bb.xlen,bb.ylen,bb.zlen], 'cad_volume_mm3':shape.Volume()}
    if mesh is not None:
        result.update({'watertight':bool(mesh.is_watertight),
                       'consistent_winding':bool(mesh.is_winding_consistent),
                       'mesh_components':len(mesh.split(only_watertight=False)),
                       'triangles':len(mesh.faces), 'mesh_volume_mm3':float(mesh.volume),
                       'mesh_dimensions_mm':mesh.extents.tolist()})
    return result


def export_all(p: Parameters, out: Path, small_width: float) -> None:
    if not (0 < small_width < p.width):
        raise ValueError('缩小版宽度必须大于零、小于原尺寸宽度。')
    out.mkdir(parents=True, exist_ok=True)
    full_dir = out/'full_size'
    tag = f'{small_width:g}mm'
    small_dir = out/f'scale_{tag}'
    full_dir.mkdir(exist_ok=True); small_dir.mkdir(exist_ok=True)
    print('建立实体…', flush=True)
    parts, wires = build(p)
    s = small_width/p.width
    report:dict[str,Any] = {'units':'mm', 'scale':s, 'scale_percent':100*s,
                           'scale_definition':'x,y,z and all features scaled uniformly; no thickening',
                           'nominal_full_dimensions_mm':[p.width,p.depth,p.height],
                           'nominal_small_dimensions_mm':[small_width,p.depth*s,p.height*s],
                           'parts':{}, 'parameters':asdict(p), 'bottom_hole_centres':BOTTOM_HOLES,
                           'limitations':['photo-derived mockup, not original engineering data',
                                          'no physical print or original-part fit test performed']}
    # STEP 保留装配方向，STL 为逐件打印方向；两者只有刚体变换的差别。
    for name, shape in parts.items():
        print(f'导出 {name}…', flush=True)
        fullstem = f'HSS0130_{name}_1to1'
        smallstem = f'HSS0130_{name}_{tag}'
        cq.exporters.export(shape, str(full_dir/(fullstem+'.step')), 'STEP')
        cq.exporters.export(shape.scale(s), str(small_dir/(smallstem+'.step')), 'STEP')
        oriented = bed_orient(shape, name, p)
        mesh = export_stl(oriented, full_dir/(fullstem+'.stl'), p)
        scaled_mesh = mesh.copy(); scaled_mesh.apply_scale(s)
        scaled_mesh.export(small_dir/(smallstem+'.stl'))
        report['parts'][name] = {'full':stats(shape,mesh), 'small':stats(shape.scale(s),scaled_mesh),
                                'strict_vertex_scale':bool(np.allclose(scaled_mesh.vertices, mesh.vertices*s,
                                                                     rtol=0,atol=1e-10)),
                                'printing_orientation':'top face down' if name=='shell' else 'flat face down'}
    # 装配中保留可拆卸件与间隙，不加入未测量的锁扣、螺柱或加强筋。
    for directory, factor, suffix in [(full_dir,1.0,'1to1'),(small_dir,s,tag)]:
        assy = cq.Assembly(name='HSS0130_PHOTO_ESTIMATE_v1')
        colors = {'shell':cq.Color(0.88,0.88,0.83),
                  'bottom':cq.Color(0.42,0.45,0.47),
                  'panel_blank':cq.Color(0.58,0.61,0.63)}
        for name in ('shell','bottom','panel_blank'):
            assy.add(parts[name].scale(factor),name=name+'_ESTIMATE',color=colors[name])
        assy.export(str(directory/f'HSS0130_assembly_{suffix}.step'))
    # 三个可拆件按打印方向排列在一个平台上。缩放之后只调整摆放位置。
    layout_shapes=[]; next_y=0.0
    for name in ('shell','bottom','panel_blank'):
        sh=bed_orient(parts[name],name,p).scale(s).translate((0,next_y,0))
        layout_shapes.append(sh)
        next_y=sh.BoundingBox().ymax+8.0
    layout=cq.Compound.makeCompound(layout_shapes)
    cq.exporters.export(layout,str(small_dir/f'HSS0130_three_parts_print_layout_{tag}.3mf'),
                        '3MF', tolerance=p.mesh_tolerance*s,
                        angularTolerance=p.mesh_angular_tolerance)
    layout_scene = trimesh.load(small_dir/f'HSS0130_three_parts_print_layout_{tag}.3mf')
    report['three_part_layout_mm'] = layout_scene.extents.tolist()
    report['three_part_layout_watertight'] = all(m.is_watertight for m in layout_scene.geometry.values())
    # 轮廓 DXF 仅为模型截面，不作为原装配合的加工图。
    reference=out/'reference'; reference.mkdir(exist_ok=True)
    for name, wire in wires.items():
        cq.exporters.export(cq.Workplane('XY').newObject([wire]),
                            str(reference/f'{name}_1to1_ESTIMATE.dxf'),'DXF')
    (out/'validation_report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    (out/'source').mkdir(exist_ok=True)
    (out/'source'/'parameters.json').write_text(json.dumps(asdict(p),indent=2,ensure_ascii=False),encoding='utf-8')
    print(f'完成。缩小比例={100*s:.6f}%，布局尺寸={report["three_part_layout_mm"]}',flush=True)


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--out',type=Path,default=Path(__file__).resolve().parents[1])
    parser.add_argument('--params',type=Path)
    parser.add_argument('--small-width',type=float,default=200.0)
    args=parser.parse_args()
    try:
        values=json.loads(args.params.read_text(encoding='utf-8')) if args.params else {}
        p=Parameters(**values)
        export_all(p,args.out.resolve(),args.small_width)
    except (ValueError,TypeError,RuntimeError,OSError) as exc:
        print(f'错误：{exc}',file=sys.stderr)
        return 1
    return 0

if __name__=='__main__':
    raise SystemExit(main())
